<?php 
header("location: https://mydhl.express.dhl/");
?>